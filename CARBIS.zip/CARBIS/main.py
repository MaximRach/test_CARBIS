from dadata import Dadata
import sqlite3 as sl

def start():
    print ('ПО для получения точного адреса\nВыберете действие:\n1.Получить точный адрес\n'
           '2.Изменить настройки\n3.Выйти из программы')
    i=int(input())
    if i==1:
        get_adderess()
    elif i==2:
        b=0
        while(b==0):b=edit_settings()
    elif i==3:
        exit()
    else:print('Ошибка: Введено не подходящее значение')

def get_adderess():
    print('Введите адрес:\n')
    input_address=input()

    con = sl.connect('settings.db')
    with con:
        data = con.execute("SELECT * FROM SETTINGS WHERE id=1")
        for row in data:
            temp=row
    dadata = Dadata(temp[3])
    result_address = dadata.suggest(name="address", query=input_address,  language=temp[4], url=temp[1])
    j=1
    for i in result_address:
        print(str(j)+'.'+i['value'])
        j+=1
    input_num=int(input())
    if input_num>10 or input_num<1:
        print('Ошибка: Введено не подходящее значение')
    else:
        temp=result_address[int(input_num)-1]
        print('Широта: '+temp['data']['geo_lat']+' Долгота: '+temp['data']['geo_lon'])

def edit_settings():
    con = sl.connect('settings.db')
    with con:
        data = con.execute("SELECT * FROM SETTINGS WHERE id=1")
        for row in data:
            temp=row
    print('Изменить настройки\nВыберете действие:\n1.Изменить url\n'
          '2.Изменить API ключ\n3.Изменить язык\n4.Вернуться в программу')
    i = int(input())
    if i == 1:
        print('Текущий url:' + temp[1] + '. \n1.Изменить\n2.Вернуть базовое значение\n3.Вернуться')
        i = int(input())
        if i == 1:
            print('Введите новый url:')
            inputurl = input()
            with con:
                con.execute("UPDATE SETTINGS SET url = '" + inputurl + "' WHERE id = 1")
            return 0
        elif i == 2:
            with con:
                con.execute("UPDATE SETTINGS SET url = '" + temp[2] + "' WHERE id = 1")
            return 0
        elif i==3:
            return 0
        else:
            print('Ошибка: Введено не подходящее значение')
            return 0
    elif i == 2:
        print('Текущий API ключ:'+ temp[3]+'. Изменить:\n1.Да\n2.Нет')
        i = int(input())
        if i == 1:
            print('Введите новый api ключ:')
            inputapi=input()
            with con:
                con.execute("UPDATE SETTINGS SET token = '"+inputapi+"' WHERE id = 1")
            return 0
        elif i == 2:
            return 0
        else:
            print('Ошибка: Введено не подходящее значение')
            return 0
    elif i == 3:
        print('Текущий язык:'+ temp[4]+'. Изменить:\n1.Да\n2.Нет')
        i = int(input())
        if i == 1:
            with con:
                if temp[4]=='ru':con.execute("UPDATE SETTINGS SET lang = 'en' WHERE id = 1")
                else:con.execute("UPDATE SETTINGS SET lang = 'ru' WHERE id = 1")
            return 0
        elif i == 2:
            return 0
        else:
            print('Ошибка: Введено не подходящее значение')
            return 0
    elif i == 4:
        return 1
    else:
        print('Ошибка: Введено не подходящее значение')
        return 0

if __name__ == '__main__':
    while(True):start()